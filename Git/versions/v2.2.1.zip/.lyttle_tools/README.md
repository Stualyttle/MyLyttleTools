# Lyttle Git Tools: Config

This is the config file for the Lyttle Git Tools.

## Config

run `npm start` to install the app.
If any errors occur, run `npm start` or `npm run install` again.
