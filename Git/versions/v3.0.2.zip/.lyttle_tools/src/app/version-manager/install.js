const fs = require("fs");

fs.writeFileSync(
  "./.lyttle_tools/src/assets/version-manager/version.txt",
  "0.0.0.0: "
);
