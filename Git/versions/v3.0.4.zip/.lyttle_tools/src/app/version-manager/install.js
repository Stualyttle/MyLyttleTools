const fs = require("fs");

fs.writeFileSync("./version.txt", "0.0.0.0: ");
